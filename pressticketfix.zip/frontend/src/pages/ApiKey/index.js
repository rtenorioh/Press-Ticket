import AddCircleOutline from '@mui/icons-material/AddCircleOutline';
import DeleteOutline from '@mui/icons-material/DeleteOutline';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import FileCopy from '@mui/icons-material/FileCopy';
import VpnKeyRounded from '@mui/icons-material/VpnKeyRounded';
import {
    Accordion,
    AccordionDetails,
    AccordionSummary,
    Box,
    Button,
    Checkbox,
    Chip,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControlLabel,
    Grid,
    IconButton,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TextField,
    Tooltip,
    Typography
} from '@mui/material';
import Stack from '@mui/material/Stack';
import { styled, useTheme } from '@mui/material/styles';
import { useCallback, useEffect, useState } from "react";
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';
import ConfirmationModal from '../../components/ConfirmationModal';
import MainContainer from '../../components/MainContainer';
import MainHeader from '../../components/MainHeader';
import MainHeaderButtonsWrapper from '../../components/MainHeaderButtonsWrapper';
import TableRowSkeleton from "../../components/TableRowSkeleton";
import Title from '../../components/Title';
import api from '../../services/api';

const MainPaper = styled(Paper)(({ theme }) => ({
    flex: 1,
    padding: theme.spacing(2),
    margin: theme.spacing(2),
    overflowY: 'scroll',
    borderRadius: theme.shape.borderRadius,
    boxShadow: '0 4px 10px rgba(0,0,0,0.05)',
    ...theme.scrollbarStyles
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    padding: theme.spacing(1, 2),
    fontSize: '0.875rem',
}));

const StyledDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogTitle-root': {
        backgroundColor: theme.palette.primary.main,
        color: '#fff',
        '& .MuiTypography-root': {
            fontWeight: 500,
        },
        padding: theme.spacing(2),
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(2),
        backgroundColor: '#f5f5f5',
    },
}));

const StyledTableHead = styled(TableHead)(({ theme }) => ({
    backgroundColor: theme.palette.background.default,
    '& .MuiTableCell-root': {
        color: theme.palette.text.secondary,
        fontWeight: 600,
    }
}));

const TokenDisplay = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(1),
    maxWidth: 280,
    [theme.breakpoints.down('md')]: {
        maxWidth: 180,
    },
}));

const TokenText = styled(Typography)(({ theme }) => ({
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    fontSize: '0.875rem',
    fontFamily: 'monospace',
    backgroundColor: theme.palette.background.default,
    padding: theme.spacing(0.5, 1),
    borderRadius: theme.shape.borderRadius,
}));

const ALL_PERMISSIONS = [
    'create:contacts', 'read:contacts', 'update:contacts', 'delete:contacts',
    'create:messages', 'read:messages', 'update:messages', 'delete:messages',
    'create:queue', 'read:queue', 'update:queue', 'delete:queue',
    'create:tags', 'read:tags', 'update:tags', 'delete:tags',
    'create:tickets', 'read:tickets', 'update:tickets', 'delete:tickets',
    'create:whatsapp', 'read:whatsapp', 'update:whatsapp', 'delete:whatsapp', 'write:whatsapp-pairing',
    'create:whatsappsession', 'update:whatsappsession', 'delete:whatsappsession',
    'read:activity-logs',
    'create:backups', 'read:backups', 'update:backups', 'delete:backups',
    'create:error-logs', 'read:error-logs', 'delete:error-logs',
    'read:network-status',
    'read:queue-monitor',
    'read:system-update', 'write:system-update',
    'read:version', 'write:whatsapp-lib',
    'write:system', 'read:system-resources',
    'read:videos', 'write:videos',
    'create:users', 'read:users', 'update:users', 'delete:users',
    'create:quickAnswers', 'read:quickAnswers', 'update:quickAnswers', 'delete:quickAnswers',
    'create:client-status', 'read:client-status', 'update:client-status', 'delete:client-status',
    'read:groups', 'write:groups',
    'write:presence',
    'read:profile',
    'read:settings', 'update:settings',
];

const ApiKey = () => {
    const { t } = useTranslation();
    const theme = useTheme();
    const [tokens, setTokens] = useState([]);
    const [loading, setLoading] = useState(false);
    const [hasMore, setHasMore] = useState(true);
    const [pageNumber, setPageNumber] = useState(1);
    const [total, setTotal] = useState(0);
    const [openNewDialog, setOpenNewDialog] = useState(false);
    const [confirmModalOpen, setConfirmModalOpen] = useState(false);
    const [tokenToDelete, setTokenToDelete] = useState(null);
    const [createdToken, setCreatedToken] = useState(null);
    const [newToken, setNewToken] = useState({
        name: '',
        permissions: []
    });

    const fetchTokens = async (page = 1) => {
        try {
            setLoading(true);
            const { data } = await api.get('/api-tokens', {
                params: {
                    pageNumber: page,
                    pageSize: 20
                }
            });

            if (page === 1) {
                setTokens(data.tokens);
            } else {
                setTokens(prev => [...prev, ...data.tokens]);
            }

            setTotal(data.count);
            setHasMore(data.hasMore);
            setPageNumber(page);
        } catch (err) {
            console.error(err);
            toast.error('Erro ao carregar tokens');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchTokens();
    }, []);

    const handleScroll = useCallback((e) => {
        if (loading || !hasMore) return;

        const { scrollHeight, scrollTop, clientHeight } = e.target;
        const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;

        if (isNearBottom) {
            fetchTokens(pageNumber + 1);
        }
    }, [loading, hasMore, pageNumber]);

    const handleClose = () => {
        setOpenNewDialog(false);
        setNewToken({
            name: '',
            permissions: []
        });
    };

    const handlePermissionChange = (permission) => {
        setNewToken(prev => ({
            ...prev,
            permissions: prev.permissions.includes(permission)
                ? prev.permissions.filter(p => p !== permission)
                : [...prev.permissions, permission]
        }));
    };

    const handleNameChange = (e) => {
        if (!e || !e.target) return;
        const value = e.target.value || '';
        setNewToken(prev => ({
            ...prev,
            name: value
        }));
    };

    const handleCreateToken = async () => {
        try {
            const payload = {
                name: newToken.name,
                permissions: newToken.permissions
            };

            const { data } = await api.post('/api-tokens', payload);
            await fetchTokens();
            setOpenNewDialog(false);
            setNewToken({
                name: '',
                permissions: []
            });
            // O token em texto puro só é retornado neste momento (o backend
            // armazena apenas o hash). Exibimos uma única vez para o usuário copiar.
            if (data?.token) {
                setCreatedToken({ name: data.name, token: data.token });
            }
            toast.success(t("apiKey.messages.success.created"));
        } catch (err) {
            console.error(err);
            if (err.response?.data?.error === 'ERR_TOKEN_NAME_ALREADY_EXISTS') {
                toast.error(t("apiKey.messages.error.nameExists"));
            } else {
                toast.error(err?.response?.data?.message || t("apiKey.messages.error.create"));
            }
        }
    };

    const handleDeleteToken = async () => {
        try {
            await api.delete(`/api-tokens/${tokenToDelete}`);
            await fetchTokens();
            toast.success(t("apiKey.messages.success.deleted"));
            setConfirmModalOpen(false);
            setTokenToDelete(null);
        } catch (err) {
            console.error(err);
            toast.error(err?.response?.data?.message || t("apiKey.messages.error.delete"));
        }
    };

    const copyTextToClipboard = async (text) => {
        if (!text) return false;
        // Caminho preferencial: Clipboard API (requer contexto seguro / HTTPS)
        if (navigator.clipboard && window.isSecureContext) {
            try {
                await navigator.clipboard.writeText(text);
                return true;
            } catch (_) {
                // cai no fallback abaixo
            }
        }
        // Fallback para HTTP ou navegadores sem Clipboard API
        try {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            textarea.style.top = '0';
            textarea.style.left = '0';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.focus();
            textarea.select();
            const ok = document.execCommand('copy');
            document.body.removeChild(textarea);
            return ok;
        } catch (_) {
            return false;
        }
    };

    const handleCopyToken = async (token) => {
        // Na listagem o token vem vazio (o backend guarda apenas o hash).
        // O valor completo só existe no momento da criação.
        if (!token) {
            toast.info(t(
                "apiKey.messages.info.tokenHidden",
                "Por segurança, a chave só é exibida no momento da criação. Gere um novo token para obter a chave."
            ));
            return;
        }
        const ok = await copyTextToClipboard(token);
        if (ok) {
            toast.success(t("apiKey.messages.success.copy"));
        } else {
            toast.error(t(
                "apiKey.messages.error.copy",
                "Não foi possível copiar. Copie manualmente."
            ));
        }
    };

    const renderPermissionName = (permission) => {
        const names = {
            // Contatos
            'create:contacts': t("apiKey.permissions.createContacts"),
            'read:contacts': t("apiKey.permissions.readContacts"),
            'update:contacts': t("apiKey.permissions.updateContacts"),
            'delete:contacts': t("apiKey.permissions.deleteContacts"),
            
            // Mensagens
            'create:messages': t("apiKey.permissions.createMessages"),
            'read:messages': t("apiKey.permissions.readMessages"),
            'update:messages': t("apiKey.permissions.updateMessages"),
            'delete:messages': t("apiKey.permissions.deleteMessages"),
            
            // Setores
            'create:queue': t("apiKey.permissions.createQueue"),
            'read:queue': t("apiKey.permissions.readQueue"),
            'update:queue': t("apiKey.permissions.updateQueue"),
            'delete:queue': t("apiKey.permissions.deleteQueue"),
            
            // Tags
            'create:tags': t("apiKey.permissions.createTags"),
            'read:tags': t("apiKey.permissions.readTags"),
            'update:tags': t("apiKey.permissions.updateTags"),
            'delete:tags': t("apiKey.permissions.deleteTags"),
            
            // Tickets
            'create:tickets': t("apiKey.permissions.createTickets"),
            'read:tickets': t("apiKey.permissions.readTickets"),
            'update:tickets': t("apiKey.permissions.updateTickets"),
            'delete:tickets': t("apiKey.permissions.deleteTickets"),
            
            // WhatsApp
            'create:whatsapp': t("apiKey.permissions.createWhatsapp"),
            'read:whatsapp': t("apiKey.permissions.readWhatsapp"),
            'update:whatsapp': t("apiKey.permissions.updateWhatsapp"),
            'delete:whatsapp': t("apiKey.permissions.deleteWhatsapp"),
            'write:whatsapp-pairing': t("apiKey.permissions.writeWhatsappPairing"),
            
            // Sessões de WhatsApp
            'create:whatsappsession': t("apiKey.permissions.createWhatsappSession"),
            'update:whatsappsession': t("apiKey.permissions.updateWhatsappSession"),
            'delete:whatsappsession': t("apiKey.permissions.deleteWhatsappSession"),
            
            // Logs de Atividade
            'read:activity-logs': t("apiKey.permissions.readActivityLogs"),
            
            // Backups
            'create:backups': t("apiKey.permissions.createBackups"),
            'read:backups': t("apiKey.permissions.readBackups"),
            'update:backups': t("apiKey.permissions.updateBackups"),
            'delete:backups': t("apiKey.permissions.deleteBackups"),
            
            // Logs de Erro
            'create:error-logs': t("apiKey.permissions.createErrorLogs"),
            'read:error-logs': t("apiKey.permissions.readErrorLogs"),
            'delete:error-logs': t("apiKey.permissions.deleteErrorLogs"),
            
            // Monitoramento de Rede
            'read:network-status': t("apiKey.permissions.readNetworkStatus"),
            
            // Monitoramento de Setor
            'read:queue-monitor': t("apiKey.permissions.readQueueMonitor"),
            
            // Atualização do Sistema
            'read:system-update': t("apiKey.permissions.readSystemUpdate"),
            'write:system-update': t("apiKey.permissions.writeSystemUpdate"),
            
            // Versão e Biblioteca WhatsApp
            'read:version': t("apiKey.permissions.readVersion"),
            'write:whatsapp-lib': t("apiKey.permissions.writeWhatsappLib"),
            
            // Sistema e Recursos
            'write:system': t("apiKey.permissions.writeSystem"),
            'read:system-resources': t("apiKey.permissions.readSystemResources"),
            
            // Vídeos
            'read:videos': t("apiKey.permissions.readVideos"),
            'write:videos': t("apiKey.permissions.writeVideos"),
            
            // Usuários
            'create:users': t("apiKey.permissions.createUsers"),
            'read:users': t("apiKey.permissions.readUsers"),
            'update:users': t("apiKey.permissions.updateUsers"),
            'delete:users': t("apiKey.permissions.deleteUsers"),
            
            // Respostas Rápidas
            'create:quickAnswers': t("apiKey.permissions.createQuickAnswers"),
            'read:quickAnswers': t("apiKey.permissions.readQuickAnswers"),
            'update:quickAnswers': t("apiKey.permissions.updateQuickAnswers"),
            'delete:quickAnswers': t("apiKey.permissions.deleteQuickAnswers"),
            
            // Status de Clientes
            'create:client-status': t("apiKey.permissions.createClientStatus"),
            'read:client-status': t("apiKey.permissions.readClientStatus"),
            'update:client-status': t("apiKey.permissions.updateClientStatus"),
            'delete:client-status': t("apiKey.permissions.deleteClientStatus"),
            
            // Grupos do WhatsApp
            'read:groups': t("apiKey.permissions.readGroups"),
            'write:groups': t("apiKey.permissions.writeGroups"),
            
            // Presença (Indicadores de Digitação/Gravação)
            'write:presence': t("apiKey.permissions.writePresence"),
            
            // Autenticação
            'read:profile': t("apiKey.permissions.readProfile"),

            // Configurações
            'read:settings': t("apiKey.permissions.readSettings"),
            'update:settings': t("apiKey.permissions.writeSettings")
        };
        return names[permission] || permission;
    };

    const hasSelectedPermissions = newToken.permissions.length > 0;

    return (
        <MainContainer>
            <MainHeader>
                <Title>{t("apiKey.title")} {total > 0 ? `(${total})` : ""}</Title>
                <MainHeaderButtonsWrapper>
                    <Tooltip title={t("apiKey.button.new")} arrow>
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={() => setOpenNewDialog(true)}
                            sx={{
                                borderRadius: 2,
                                px: { xs: 1, sm: 2 },
                                '& .MuiButton-startIcon': {
                                    mr: { xs: 0, sm: 1 }
                                }
                            }}
                        >
                            <AddCircleOutline />
                        </Button>
                    </Tooltip>
                </MainHeaderButtonsWrapper>
            </MainHeader>
            <MainPaper
                variant="outlined"
                onScroll={handleScroll}
            >
                <TableContainer sx={{ borderRadius: 1, overflow: 'hidden' }}>
                    <Table>
                        <StyledTableHead>
                            <TableRow>
                                <StyledTableCell>{t("apiKey.table.name")}</StyledTableCell>
                                <StyledTableCell>{t("apiKey.table.token")}</StyledTableCell>
                                <StyledTableCell>{t("apiKey.table.permissions")}</StyledTableCell>
                                <StyledTableCell align="center">{t("apiKey.table.permissionsCount")}</StyledTableCell>
                                <StyledTableCell>{t("apiKey.table.created_at")}</StyledTableCell>
                                <StyledTableCell align="center">{t("apiKey.table.actions")}</StyledTableCell>
                            </TableRow>
                        </StyledTableHead>
                        <TableBody>
                            {loading && tokens.length === 0 ? (
                                <TableRowSkeleton columns={6} />
                            ) : tokens.length === 0 ? (
                                <TableRow>
                                    <StyledTableCell colSpan={6} align="center">
                                        <Typography variant="body2" color="textSecondary">
                                            {t("apiKey.messages.noTokens")}
                                        </Typography>
                                    </StyledTableCell>
                                </TableRow>
                            ) : tokens.map((token) => (
                                <TableRow key={token.id} hover>
                                    <StyledTableCell>
                                        <Typography variant="body2" fontWeight={500}>
                                            {token.name}
                                        </Typography>
                                    </StyledTableCell>
                                    <StyledTableCell>
                                        <TokenDisplay>
                                            <TokenText>
                                                {token.token || '••••••••••••••••'}
                                            </TokenText>
                                            <Tooltip
                                                title={token.token
                                                    ? t("apiKey.button.copy")
                                                    : t("apiKey.messages.info.tokenHidden", "A chave só é exibida na criação")}
                                                arrow
                                            >
                                                <IconButton
                                                    size="small"
                                                    onClick={() => handleCopyToken(token.token)}
                                                    sx={{ bgcolor: 'background.default', '&:hover': { bgcolor: 'action.hover' } }}
                                                >
                                                    <FileCopy fontSize="small" />
                                                </IconButton>
                                            </Tooltip>
                                        </TokenDisplay>
                                    </StyledTableCell>
                                    <StyledTableCell>
                                        <Typography variant="body2" color="textSecondary">
                                            {Array.isArray(token.permissions) ? token.permissions.map(renderPermissionName).join(', ') : ''}
                                        </Typography>
                                    </StyledTableCell>
                                    <StyledTableCell align="center">
                                        <Tooltip title={`${token.permissions?.length || 0} ${t("apiKey.table.permissionsGranted")}`} arrow>
                                            <Chip
                                                label={token.permissions?.length || 0}
                                                size="small"
                                                color="primary"
                                            />
                                        </Tooltip>
                                    </StyledTableCell>
                                    <StyledTableCell>
                                        <Typography variant="body2" color="textSecondary">
                                            {new Date(token.createdAt).toLocaleString()}
                                        </Typography>
                                    </StyledTableCell>
                                    <StyledTableCell align="center">
                                        <Tooltip title={t("apiKey.button.delete")} arrow>
                                            <IconButton
                                                size="small"
                                                onClick={() => {
                                                    setTokenToDelete(token.id);
                                                    setConfirmModalOpen(true);
                                                }}
                                                sx={{ color: 'error.main', '&:hover': { bgcolor: 'error.lighter' } }}
                                            >
                                                <DeleteOutline fontSize="small" />
                                            </IconButton>
                                        </Tooltip>
                                    </StyledTableCell>
                                </TableRow>
                            ))}
                            {loading && <TableRowSkeleton columns={6} />}
                        </TableBody>
                    </Table>
                </TableContainer>
            </MainPaper>

            <StyledDialog
                open={openNewDialog}
                onClose={handleClose}
                maxWidth="sm"
                fullWidth
                PaperProps={{
                    sx: {
                        borderRadius: 2,
                        boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
                    }
                }}
            >
                <DialogTitle>
                    <Stack direction="row" alignItems="center">
                        <VpnKeyRounded fontSize="small" sx={{ mr: 1.5 }}/>
                        {t("apiKey.modal.title")}
                    </Stack>
                </DialogTitle>
                <DialogContent sx={{ pt: 0 }}>
                    <TextField
                        autoFocus
                        margin="dense"
                        label={t("apiKey.modal.name")}
                        type="text"
                        fullWidth
                        value={newToken.name}
                        onChange={handleNameChange}
                        variant="outlined"
                        sx={{ mb: 2, mt: 1 }}
                    />
                    <Box sx={{ width: '100%' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
                            <Typography variant="subtitle1" fontWeight={500}>
                                {t("apiKey.modal.permissions")}
                            </Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                                <Typography
                                    variant="caption"
                                    sx={{ fontWeight: 500 }}
                                    color={newToken.permissions.length === 0 ? 'error.main' : 'success.main'}
                                >
                                    {newToken.permissions.length === 0
                                        ? `0 ${t("apiKey.modal.permissionsSelected")}`
                                        : `${newToken.permissions.length} ${t("apiKey.modal.permissionsOf")} ${ALL_PERMISSIONS.length} ${t("apiKey.modal.permissionsSelected")}`
                                    }
                                </Typography>
                                <Button
                                    size="small"
                                    variant="outlined"
                                    color="primary"
                                    onClick={() => {
                                        if (newToken.permissions.length === ALL_PERMISSIONS.length) {
                                            setNewToken(prev => ({ ...prev, permissions: [] }));
                                        } else {
                                            setNewToken(prev => ({ ...prev, permissions: ALL_PERMISSIONS }));
                                        }
                                    }}
                                    sx={{ borderRadius: 20, textTransform: 'none' }}
                                >
                                    {newToken.permissions.length === ALL_PERMISSIONS.length
                                        ? t("apiKey.modal.buttons.unselectAll")
                                        : t("apiKey.modal.buttons.selectAll")}
                                </Button>
                            </Box>
                        </Box>
                        
                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.contacts")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:contacts', 'read:contacts', 'update:contacts', 'delete:contacts'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                        
                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.messages")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:messages', 'read:messages', 'update:messages', 'delete:messages'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                        
                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.queues")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:queue', 'read:queue', 'update:queue', 'delete:queue'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                        
                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.tags")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:tags', 'read:tags', 'update:tags', 'delete:tags'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                        
                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.tickets")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:tickets', 'read:tickets', 'update:tickets', 'delete:tickets'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                        
                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.whatsapp")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:whatsapp', 'read:whatsapp', 'update:whatsapp', 'delete:whatsapp', 'write:whatsapp-pairing'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                        
                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.whatsappSession")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:whatsappsession', 'update:whatsappsession', 'delete:whatsappsession'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.activityLogs")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['read:activity-logs'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.backups")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:backups', 'read:backups', 'update:backups', 'delete:backups'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.errorLogs")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:error-logs', 'read:error-logs', 'delete:error-logs'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.networkStatus")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['read:network-status'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.queueMonitor")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['read:queue-monitor'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.systemUpdate")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['read:system-update', 'write:system-update'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.versionWhatsapp")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['read:version', 'write:whatsapp-lib'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.systemResources")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['write:system', 'read:system-resources'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.videos")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['read:videos', 'write:videos'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.users")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:users', 'read:users', 'update:users', 'delete:users'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.quickAnswers")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:quickAnswers', 'read:quickAnswers', 'update:quickAnswers', 'delete:quickAnswers'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.clientStatus")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['create:client-status', 'read:client-status', 'update:client-status', 'delete:client-status'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.whatsappGroups")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['read:groups', 'write:groups'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.presence")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['write:presence'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                        
                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.authentication")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['read:profile'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>

                        <Accordion sx={{ mb: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '4px !important', '&:before': { display: 'none' } }}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{
                                    backgroundColor: theme.palette.background.default,
                                    borderRadius: '4px',
                                }}
                            >
                                <Typography variant="subtitle2" fontWeight={500}>
                                    {t("apiKey.categories.settings")}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 2 }}>
                                <Grid container spacing={1}>
                                    {['read:settings', 'update:settings'].map((permission) => (
                                        <Grid item xs={12} sm={6} key={permission}>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        checked={newToken.permissions.includes(permission)}
                                                        onChange={() => handlePermissionChange(permission)}
                                                        color="primary"
                                                        size="small"
                                                    />
                                                }
                                                label={<Typography variant="body2">{renderPermissionName(permission)}</Typography>}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                    </Box>
                </DialogContent>
                <DialogActions sx={{ px: 3, pb: 3, pt: 1 }}>
                    <Button 
                        onClick={handleClose} 
                        variant="contained"
                        sx={{ 
                            borderRadius: 20,
                            backgroundColor: '#e0e0e0',
                            color: '#757575',
                            '&:hover': {
                                backgroundColor: '#d5d5d5',
                            },
                            textTransform: 'uppercase',
                            fontWeight: 'bold',
                        }}
                    >
                        {t("apiKey.modal.buttons.cancel")}
                    </Button>
                    <Button
                        onClick={handleCreateToken}
                        variant="contained"
                        disabled={!newToken.name || !hasSelectedPermissions}
                        sx={{ 
                            borderRadius: 20, 
                            ml: 2,
                            backgroundColor: theme.palette.primary.main,
                            '&:hover': {
                                backgroundColor: theme.palette.secondary.main,
                            },
                            textTransform: 'uppercase',
                            fontWeight: 'bold',
                        }}
                    >
                        {t("apiKey.modal.buttons.save")}
                    </Button>
                </DialogActions>
            </StyledDialog>

            <StyledDialog
                open={Boolean(createdToken)}
                onClose={() => setCreatedToken(null)}
                maxWidth="sm"
                fullWidth
                PaperProps={{
                    sx: {
                        borderRadius: 2,
                        boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
                    }
                }}
            >
                <DialogTitle>
                    <Stack direction="row" alignItems="center">
                        <VpnKeyRounded fontSize="small" sx={{ mr: 1.5 }} />
                        {t("apiKey.createdModal.title", "Token criado com sucesso")}
                    </Stack>
                </DialogTitle>
                <DialogContent sx={{ pt: 3 }}>
                    <Typography variant="body2" color="textSecondary" sx={{ mb: 2 }}>
                        {t(
                            "apiKey.createdModal.warning",
                            "Copie a chave agora. Por segurança, ela não poderá ser exibida novamente."
                        )}
                    </Typography>
                    <Box
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 1,
                            p: 1.5,
                            borderRadius: 1,
                            border: `1px solid ${theme.palette.divider}`,
                            backgroundColor: theme.palette.background.default,
                        }}
                    >
                        <Typography
                            sx={{
                                flex: 1,
                                fontFamily: 'monospace',
                                fontSize: '0.875rem',
                                wordBreak: 'break-all',
                            }}
                        >
                            {createdToken?.token}
                        </Typography>
                        <Tooltip title={t("apiKey.button.copy")} arrow>
                            <IconButton
                                size="small"
                                onClick={() => handleCopyToken(createdToken?.token)}
                            >
                                <FileCopy fontSize="small" />
                            </IconButton>
                        </Tooltip>
                    </Box>
                </DialogContent>
                <DialogActions sx={{ px: 3, pb: 3, pt: 1 }}>
                    <Button
                        onClick={() => handleCopyToken(createdToken?.token)}
                        variant="outlined"
                        color="primary"
                        sx={{ borderRadius: 20, textTransform: 'none', fontWeight: 'bold' }}
                    >
                        {t("apiKey.button.copy")}
                    </Button>
                    <Button
                        onClick={() => setCreatedToken(null)}
                        variant="contained"
                        color="primary"
                        sx={{ borderRadius: 20, ml: 2, textTransform: 'uppercase', fontWeight: 'bold' }}
                    >
                        {t("apiKey.createdModal.done", "Concluído")}
                    </Button>
                </DialogActions>
            </StyledDialog>

            <ConfirmationModal
                title="Excluir Token"
                open={confirmModalOpen}
                onClose={() => setConfirmModalOpen(false)}
                onConfirm={handleDeleteToken}
            >
                {t("apiKey.confirmationModal.message")}
            </ConfirmationModal>
        </MainContainer>
    );
};

export default ApiKey;
